﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    internal class Mensalista : Empregado //classe mensalista é herança (filha) da classe empregado
    {
        public double SalarioMensal { get; set; }//propriedades
        public override double SalarioBruto()//override = sobrescrever o método
        {
            return SalarioMensal;
        }


        public Mensalista()
        {
            System.Windows.Forms.MessageBox.Show("aqui é mensalista");
        }
        public Mensalista(int matx, string nomex, DateTime datax, double salx)
        {
            this.NomeEmpregado = nomex;
            this.Matricula = matx;
            this.DataEntradaEmpresa = datax;
            this.SalarioMensal = salx;


        }
        public static string Empresa = "Toyota";
        public const String Fiial = "Filial Toyota";
    }
}
