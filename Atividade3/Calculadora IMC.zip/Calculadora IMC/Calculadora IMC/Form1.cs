﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora_IMC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click_Click(object sender, EventArgs e)
        {
            double altura = Convert.ToDouble(txtAltura.Text);
            double peso = Convert.ToDouble(txtPeso.Text);

            double imc = CalcularIMC(peso, altura);

            txtResultadoIMC.Text = imc.ToString("F2");

        }

        private double CalcularIMC(double peso, double altura)
        {
            
            return peso / (altura * altura);
        }
        private string InterpretarIMC(double imc)
        {
            string categoria = "";

            if (imc < 18.5)
                categoria = "Abaixo do peso";
            else if (imc >= 18.5 && imc < 25)
                categoria = "Peso normal";
            else if (imc >= 25 && imc < 30)
                categoria = "Sobrepeso";
            else if (imc >= 30 && imc < 35)
                categoria = "Obesidade Grau I";
            else if (imc >= 35 && imc < 40)
                categoria = "Obesidade Grau II (severa)";
            else
                categoria = "Obesidade Grau III (mórbida)";

            return $"Seu IMC indica: {categoria}";
        }

        

        private void btnCLEAR_Click_1(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtPeso.Clear();
            txtResultadoIMC.Text = string.Empty;
        }

        private void btn_SAIR_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
