﻿namespace Calculadora_IMC
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtAltura = new System.Windows.Forms.TextBox();
            this.txtPeso = new System.Windows.Forms.TextBox();
            this.btnCalcular_Click = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtResultadoIMC = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnCLEAR = new System.Windows.Forms.Button();
            this.btn_SAIR = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtAltura
            // 
            this.txtAltura.Location = new System.Drawing.Point(172, 89);
            this.txtAltura.Name = "txtAltura";
            this.txtAltura.Size = new System.Drawing.Size(100, 20);
            this.txtAltura.TabIndex = 0;
            // 
            // txtPeso
            // 
            this.txtPeso.Location = new System.Drawing.Point(172, 141);
            this.txtPeso.Name = "txtPeso";
            this.txtPeso.Size = new System.Drawing.Size(100, 20);
            this.txtPeso.TabIndex = 1;
            // 
            // btnCalcular_Click
            // 
            this.btnCalcular_Click.Location = new System.Drawing.Point(172, 252);
            this.btnCalcular_Click.Name = "btnCalcular_Click";
            this.btnCalcular_Click.Size = new System.Drawing.Size(100, 53);
            this.btnCalcular_Click.TabIndex = 2;
            this.btnCalcular_Click.Text = "Calcular";
            this.btnCalcular_Click.UseVisualStyleBackColor = true;
            this.btnCalcular_Click.Click += new System.EventHandler(this.btnCalcular_Click_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(99, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Altura";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(102, 147);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Peso";
            // 
            // txtResultadoIMC
            // 
            this.txtResultadoIMC.Enabled = false;
            this.txtResultadoIMC.Location = new System.Drawing.Point(172, 208);
            this.txtResultadoIMC.Name = "txtResultadoIMC";
            this.txtResultadoIMC.Size = new System.Drawing.Size(100, 20);
            this.txtResultadoIMC.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(73, 211);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Resultado IMC";
            // 
            // btnCLEAR
            // 
            this.btnCLEAR.Location = new System.Drawing.Point(324, 252);
            this.btnCLEAR.Name = "btnCLEAR";
            this.btnCLEAR.Size = new System.Drawing.Size(94, 53);
            this.btnCLEAR.TabIndex = 7;
            this.btnCLEAR.Text = "Limpar";
            this.btnCLEAR.UseVisualStyleBackColor = true;
            this.btnCLEAR.Click += new System.EventHandler(this.btnCLEAR_Click_1);
            // 
            // btn_SAIR
            // 
            this.btn_SAIR.Location = new System.Drawing.Point(495, 252);
            this.btn_SAIR.Name = "btn_SAIR";
            this.btn_SAIR.Size = new System.Drawing.Size(86, 53);
            this.btn_SAIR.TabIndex = 8;
            this.btn_SAIR.Text = "Sair";
            this.btn_SAIR.UseVisualStyleBackColor = true;
            this.btn_SAIR.Click += new System.EventHandler(this.btn_SAIR_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_SAIR);
            this.Controls.Add(this.btnCLEAR);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtResultadoIMC);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCalcular_Click);
            this.Controls.Add(this.txtPeso);
            this.Controls.Add(this.txtAltura);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtAltura;
        private System.Windows.Forms.TextBox txtPeso;
        private System.Windows.Forms.Button btnCalcular_Click;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtResultadoIMC;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnCLEAR;
        private System.Windows.Forms.Button btn_SAIR;
    }
}

