﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using Microsoft.VisualBasic;



namespace PReava
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.IsMdiContainer = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] A = new int[19];
            String aux;
            for (int i = 0; i < A.Length; i++)
            {
                aux = ($"Digite o {i + 1}º número", "Entrada de dados");
                if (!int.TryParse(aux, out A[i]))
                {
                    MessageBox.Show("Número inválido!");
                    i--;
                }
            }
            Array.Reverse(A);
            aux = "";
            foreach (int i in A)
            {
                aux += i + "\n";
            }
            MessageBox.Show(aux);
        }



        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

       

    }
    }
